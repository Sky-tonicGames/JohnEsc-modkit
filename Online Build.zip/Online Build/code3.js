gdjs.PauceCode = {};
gdjs.PauceCode.GDNewTextObjects1= [];
gdjs.PauceCode.GDNewTextObjects2= [];
gdjs.PauceCode.GDNewText2Objects1= [];
gdjs.PauceCode.GDNewText2Objects2= [];
gdjs.PauceCode.GDNewText3Objects1= [];
gdjs.PauceCode.GDNewText3Objects2= [];
gdjs.PauceCode.GDNewText4Objects1= [];
gdjs.PauceCode.GDNewText4Objects2= [];
gdjs.PauceCode.GDNewText5Objects1= [];
gdjs.PauceCode.GDNewText5Objects2= [];

gdjs.PauceCode.conditionTrue_0 = {val:false};
gdjs.PauceCode.condition0IsTrue_0 = {val:false};
gdjs.PauceCode.condition1IsTrue_0 = {val:false};


gdjs.PauceCode.eventsList0 = function(runtimeScene) {

{


gdjs.PauceCode.condition0IsTrue_0.val = false;
{
gdjs.PauceCode.condition0IsTrue_0.val = gdjs.evtTools.window.isFullScreen(runtimeScene);
}if (gdjs.PauceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewText4"), gdjs.PauceCode.GDNewText4Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText5"), gdjs.PauceCode.GDNewText5Objects1);
{for(var i = 0, len = gdjs.PauceCode.GDNewText5Objects1.length ;i < len;++i) {
    gdjs.PauceCode.GDNewText5Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.PauceCode.GDNewText4Objects1.length ;i < len;++i) {
    gdjs.PauceCode.GDNewText4Objects1[i].hide(false);
}
}}

}


{


gdjs.PauceCode.condition0IsTrue_0.val = false;
{
gdjs.PauceCode.condition0IsTrue_0.val = !(gdjs.evtTools.window.isFullScreen(runtimeScene));
}if (gdjs.PauceCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewText4"), gdjs.PauceCode.GDNewText4Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText5"), gdjs.PauceCode.GDNewText5Objects1);
{for(var i = 0, len = gdjs.PauceCode.GDNewText4Objects1.length ;i < len;++i) {
    gdjs.PauceCode.GDNewText4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.PauceCode.GDNewText5Objects1.length ;i < len;++i) {
    gdjs.PauceCode.GDNewText5Objects1[i].hide(false);
}
}}

}


{


gdjs.PauceCode.condition0IsTrue_0.val = false;
{
gdjs.PauceCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
}if (gdjs.PauceCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Game");
}}

}


{


gdjs.PauceCode.condition0IsTrue_0.val = false;
{
gdjs.PauceCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "q");
}if (gdjs.PauceCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Untitled scene");
}}

}


};

gdjs.PauceCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PauceCode.GDNewTextObjects1.length = 0;
gdjs.PauceCode.GDNewTextObjects2.length = 0;
gdjs.PauceCode.GDNewText2Objects1.length = 0;
gdjs.PauceCode.GDNewText2Objects2.length = 0;
gdjs.PauceCode.GDNewText3Objects1.length = 0;
gdjs.PauceCode.GDNewText3Objects2.length = 0;
gdjs.PauceCode.GDNewText4Objects1.length = 0;
gdjs.PauceCode.GDNewText4Objects2.length = 0;
gdjs.PauceCode.GDNewText5Objects1.length = 0;
gdjs.PauceCode.GDNewText5Objects2.length = 0;

gdjs.PauceCode.eventsList0(runtimeScene);
return;

}

gdjs['PauceCode'] = gdjs.PauceCode;
