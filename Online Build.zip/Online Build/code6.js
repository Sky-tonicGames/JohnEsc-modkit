gdjs.KeypadCode = {};
gdjs.KeypadCode.GDNewTextInputObjects1= [];
gdjs.KeypadCode.GDNewTextInputObjects2= [];
gdjs.KeypadCode.GDNewTextObjects1= [];
gdjs.KeypadCode.GDNewTextObjects2= [];
gdjs.KeypadCode.GDNewText2Objects1= [];
gdjs.KeypadCode.GDNewText2Objects2= [];
gdjs.KeypadCode.GDNewText3Objects1= [];
gdjs.KeypadCode.GDNewText3Objects2= [];

gdjs.KeypadCode.conditionTrue_0 = {val:false};
gdjs.KeypadCode.condition0IsTrue_0 = {val:false};
gdjs.KeypadCode.condition1IsTrue_0 = {val:false};


gdjs.KeypadCode.eventsList0 = function(runtimeScene) {

{


gdjs.KeypadCode.condition0IsTrue_0.val = false;
{
gdjs.KeypadCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
}if (gdjs.KeypadCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewTextInput"), gdjs.KeypadCode.GDNewTextInputObjects1);

gdjs.KeypadCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.KeypadCode.GDNewTextInputObjects1.length;i<l;++i) {
    if ( gdjs.KeypadCode.GDNewTextInputObjects1[i].getString() == "" ) {
        gdjs.KeypadCode.condition0IsTrue_0.val = true;
        gdjs.KeypadCode.GDNewTextInputObjects1[k] = gdjs.KeypadCode.GDNewTextInputObjects1[i];
        ++k;
    }
}
gdjs.KeypadCode.GDNewTextInputObjects1.length = k;}if (gdjs.KeypadCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}

}


};

gdjs.KeypadCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.KeypadCode.GDNewTextInputObjects1.length = 0;
gdjs.KeypadCode.GDNewTextInputObjects2.length = 0;
gdjs.KeypadCode.GDNewTextObjects1.length = 0;
gdjs.KeypadCode.GDNewTextObjects2.length = 0;
gdjs.KeypadCode.GDNewText2Objects1.length = 0;
gdjs.KeypadCode.GDNewText2Objects2.length = 0;
gdjs.KeypadCode.GDNewText3Objects1.length = 0;
gdjs.KeypadCode.GDNewText3Objects2.length = 0;

gdjs.KeypadCode.eventsList0(runtimeScene);
return;

}

gdjs['KeypadCode'] = gdjs.KeypadCode;
