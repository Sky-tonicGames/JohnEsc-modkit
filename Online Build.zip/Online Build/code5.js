gdjs.Untitled_32scene2Code = {};
gdjs.Untitled_32scene2Code.GDNewTextObjects1= [];
gdjs.Untitled_32scene2Code.GDNewTextObjects2= [];
gdjs.Untitled_32scene2Code.GDNewText2Objects1= [];
gdjs.Untitled_32scene2Code.GDNewText2Objects2= [];
gdjs.Untitled_32scene2Code.GDNewText3Objects1= [];
gdjs.Untitled_32scene2Code.GDNewText3Objects2= [];
gdjs.Untitled_32scene2Code.GDNewText4Objects1= [];
gdjs.Untitled_32scene2Code.GDNewText4Objects2= [];
gdjs.Untitled_32scene2Code.GDNewText5Objects1= [];
gdjs.Untitled_32scene2Code.GDNewText5Objects2= [];
gdjs.Untitled_32scene2Code.GDGdevelopCompleteLogoWhiteObjects1= [];
gdjs.Untitled_32scene2Code.GDGdevelopCompleteLogoWhiteObjects2= [];
gdjs.Untitled_32scene2Code.GDNewText6Objects1= [];
gdjs.Untitled_32scene2Code.GDNewText6Objects2= [];
gdjs.Untitled_32scene2Code.GDNewText7Objects1= [];
gdjs.Untitled_32scene2Code.GDNewText7Objects2= [];

gdjs.Untitled_32scene2Code.conditionTrue_0 = {val:false};
gdjs.Untitled_32scene2Code.condition0IsTrue_0 = {val:false};
gdjs.Untitled_32scene2Code.condition1IsTrue_0 = {val:false};


gdjs.Untitled_32scene2Code.asyncCallback8566428 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("NewText7"), gdjs.Untitled_32scene2Code.GDNewText7Objects2);
{for(var i = 0, len = gdjs.Untitled_32scene2Code.GDNewText7Objects2.length ;i < len;++i) {
    gdjs.Untitled_32scene2Code.GDNewText7Objects2[i].hide(false);
}
}}
gdjs.Untitled_32scene2Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(6), (runtimeScene) => (gdjs.Untitled_32scene2Code.asyncCallback8566428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32scene2Code.eventsList1 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.Untitled_32scene2Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.Untitled_32scene2Code.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32scene2Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}if (gdjs.Untitled_32scene2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewText7"), gdjs.Untitled_32scene2Code.GDNewText7Objects1);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}{gdjs.evtTools.sound.playMusic(runtimeScene, "fast-2021-08-30_-_Boss_Time_-_www.FesliyanStudios.com.mp3", true, 100, 1);
}{for(var i = 0, len = gdjs.Untitled_32scene2Code.GDNewText7Objects1.length ;i < len;++i) {
    gdjs.Untitled_32scene2Code.GDNewText7Objects1[i].hide();
}
}}

}


{


gdjs.Untitled_32scene2Code.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32scene2Code.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Return");
}if (gdjs.Untitled_32scene2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Untitled scene");
}}

}


};

gdjs.Untitled_32scene2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32scene2Code.GDNewTextObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewTextObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewText2Objects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewText2Objects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewText3Objects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewText3Objects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewText4Objects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewText4Objects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewText5Objects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewText5Objects2.length = 0;
gdjs.Untitled_32scene2Code.GDGdevelopCompleteLogoWhiteObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDGdevelopCompleteLogoWhiteObjects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewText6Objects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewText6Objects2.length = 0;
gdjs.Untitled_32scene2Code.GDNewText7Objects1.length = 0;
gdjs.Untitled_32scene2Code.GDNewText7Objects2.length = 0;

gdjs.Untitled_32scene2Code.eventsList1(runtimeScene);
return;

}

gdjs['Untitled_32scene2Code'] = gdjs.Untitled_32scene2Code;
