gdjs.John_39storyCode = {};
gdjs.John_39storyCode.GDNewTextObjects1= [];
gdjs.John_39storyCode.GDNewTextObjects2= [];

gdjs.John_39storyCode.conditionTrue_0 = {val:false};
gdjs.John_39storyCode.condition0IsTrue_0 = {val:false};
gdjs.John_39storyCode.condition1IsTrue_0 = {val:false};


gdjs.John_39storyCode.asyncCallback8516564 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Game");
}}
gdjs.John_39storyCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(59), (runtimeScene) => (gdjs.John_39storyCode.asyncCallback8516564(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.John_39storyCode.eventsList1 = function(runtimeScene) {

{


gdjs.John_39storyCode.condition0IsTrue_0.val = false;
{
gdjs.John_39storyCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}if (gdjs.John_39storyCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "intro_narrason.mp3", false, 100, 1);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}}

}


{


gdjs.John_39storyCode.condition0IsTrue_0.val = false;
{
gdjs.John_39storyCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}if (gdjs.John_39storyCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.John_39storyCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.John_39storyCode.condition0IsTrue_0.val = false;
{
gdjs.John_39storyCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Return");
}if (gdjs.John_39storyCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Game");
}}

}


};

gdjs.John_39storyCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.John_39storyCode.GDNewTextObjects1.length = 0;
gdjs.John_39storyCode.GDNewTextObjects2.length = 0;

gdjs.John_39storyCode.eventsList1(runtimeScene);
return;

}

gdjs['John_39storyCode'] = gdjs.John_39storyCode;
