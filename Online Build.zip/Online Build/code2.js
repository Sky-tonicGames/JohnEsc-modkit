gdjs.GameCode = {};
gdjs.GameCode.GDBlueBackgroundObjects1= [];
gdjs.GameCode.GDBlueBackgroundObjects2= [];
gdjs.GameCode.GDMaskedOrcObjects1= [];
gdjs.GameCode.GDMaskedOrcObjects2= [];
gdjs.GameCode.GDWallObjects1= [];
gdjs.GameCode.GDWallObjects2= [];
gdjs.GameCode.GDNewTiledSpriteObjects1= [];
gdjs.GameCode.GDNewTiledSpriteObjects2= [];
gdjs.GameCode.GDNewTextObjects1= [];
gdjs.GameCode.GDNewTextObjects2= [];
gdjs.GameCode.GDWorngEndingTriggerObjects1= [];
gdjs.GameCode.GDWorngEndingTriggerObjects2= [];
gdjs.GameCode.GDGenericCharacter1Objects1= [];
gdjs.GameCode.GDGenericCharacter1Objects2= [];
gdjs.GameCode.GDBrassKeyObjects1= [];
gdjs.GameCode.GDBrassKeyObjects2= [];
gdjs.GameCode.GDKeypadTriggerObjects1= [];
gdjs.GameCode.GDKeypadTriggerObjects2= [];
gdjs.GameCode.GDNewText2Objects1= [];
gdjs.GameCode.GDNewText2Objects2= [];

gdjs.GameCode.conditionTrue_0 = {val:false};
gdjs.GameCode.condition0IsTrue_0 = {val:false};
gdjs.GameCode.condition1IsTrue_0 = {val:false};
gdjs.GameCode.condition2IsTrue_0 = {val:false};
gdjs.GameCode.condition3IsTrue_0 = {val:false};


gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMaskedOrcObjects1Objects = Hashtable.newFrom({"MaskedOrc": gdjs.GameCode.GDMaskedOrcObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDWallObjects1Objects = Hashtable.newFrom({"Wall": gdjs.GameCode.GDWallObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDWallObjects1Objects = Hashtable.newFrom({"Wall": gdjs.GameCode.GDWallObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDNewTiledSpriteObjects1Objects = Hashtable.newFrom({"NewTiledSprite": gdjs.GameCode.GDNewTiledSpriteObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDWorngEndingTriggerObjects1Objects = Hashtable.newFrom({"WorngEndingTrigger": gdjs.GameCode.GDWorngEndingTriggerObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMaskedOrcObjects1Objects = Hashtable.newFrom({"MaskedOrc": gdjs.GameCode.GDMaskedOrcObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMaskedOrcObjects1Objects = Hashtable.newFrom({"MaskedOrc": gdjs.GameCode.GDMaskedOrcObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDKeypadTriggerObjects1Objects = Hashtable.newFrom({"KeypadTrigger": gdjs.GameCode.GDKeypadTriggerObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMaskedOrcObjects1Objects = Hashtable.newFrom({"MaskedOrc": gdjs.GameCode.GDMaskedOrcObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDKeypadTriggerObjects1Objects = Hashtable.newFrom({"KeypadTrigger": gdjs.GameCode.GDKeypadTriggerObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDNewTiledSpriteObjects1Objects = Hashtable.newFrom({"NewTiledSprite": gdjs.GameCode.GDNewTiledSpriteObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMaskedOrcObjects1Objects = Hashtable.newFrom({"MaskedOrc": gdjs.GameCode.GDMaskedOrcObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBrassKeyObjects1Objects = Hashtable.newFrom({"BrassKey": gdjs.GameCode.GDBrassKeyObjects1});
gdjs.GameCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MaskedOrc"), gdjs.GameCode.GDMaskedOrcObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.GameCode.GDWallObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMaskedOrcObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDWallObjects1Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDMaskedOrcObjects1 */
/* Reuse gdjs.GameCode.GDWallObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDMaskedOrcObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMaskedOrcObjects1[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDWallObjects1Objects, false);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("MaskedOrc"), gdjs.GameCode.GDMaskedOrcObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.GameCode.GDNewTextObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.GameCode.GDMaskedOrcObjects1.length !== 0 ? gdjs.GameCode.GDMaskedOrcObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.GameCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDNewTextObjects1[i].setString("Currnet Time:" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3))));
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(1), true);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("MaskedOrc"), gdjs.GameCode.GDMaskedOrcObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.GameCode.GDNewTiledSpriteObjects1);
{for(var i = 0, len = gdjs.GameCode.GDMaskedOrcObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMaskedOrcObjects1[i].setPosition(205,267);
}
}{for(var i = 0, len = gdjs.GameCode.GDMaskedOrcObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMaskedOrcObjects1[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDNewTiledSpriteObjects1Objects, false);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MaskedOrc"), gdjs.GameCode.GDMaskedOrcObjects1);
gdjs.copyArray(runtimeScene.getObjects("WorngEndingTrigger"), gdjs.GameCode.GDWorngEndingTriggerObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDWorngEndingTriggerObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMaskedOrcObjects1Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Untitled scene2");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("KeypadTrigger"), gdjs.GameCode.GDKeypadTriggerObjects1);
gdjs.copyArray(runtimeScene.getObjects("MaskedOrc"), gdjs.GameCode.GDMaskedOrcObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(4), true);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMaskedOrcObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDKeypadTriggerObjects1Objects, false, runtimeScene, false);
}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
gdjs.GameCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
}
if (gdjs.GameCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Keypad");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(4), true);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("KeypadTrigger"), gdjs.GameCode.GDKeypadTriggerObjects1);
gdjs.copyArray(runtimeScene.getObjects("MaskedOrc"), gdjs.GameCode.GDMaskedOrcObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(4), false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMaskedOrcObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDKeypadTriggerObjects1Objects, false, runtimeScene, false);
}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
gdjs.GameCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
}
if (gdjs.GameCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDMaskedOrcObjects1 */
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.GameCode.GDNewTiledSpriteObjects1);
{for(var i = 0, len = gdjs.GameCode.GDMaskedOrcObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMaskedOrcObjects1[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDNewTiledSpriteObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BrassKey"), gdjs.GameCode.GDBrassKeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("MaskedOrc"), gdjs.GameCode.GDMaskedOrcObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMaskedOrcObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBrassKeyObjects1Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDBrassKeyObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDBrassKeyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDBrassKeyObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(4), true);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Pauce", false);
}}

}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDBlueBackgroundObjects1.length = 0;
gdjs.GameCode.GDBlueBackgroundObjects2.length = 0;
gdjs.GameCode.GDMaskedOrcObjects1.length = 0;
gdjs.GameCode.GDMaskedOrcObjects2.length = 0;
gdjs.GameCode.GDWallObjects1.length = 0;
gdjs.GameCode.GDWallObjects2.length = 0;
gdjs.GameCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.GameCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.GameCode.GDNewTextObjects1.length = 0;
gdjs.GameCode.GDNewTextObjects2.length = 0;
gdjs.GameCode.GDWorngEndingTriggerObjects1.length = 0;
gdjs.GameCode.GDWorngEndingTriggerObjects2.length = 0;
gdjs.GameCode.GDGenericCharacter1Objects1.length = 0;
gdjs.GameCode.GDGenericCharacter1Objects2.length = 0;
gdjs.GameCode.GDBrassKeyObjects1.length = 0;
gdjs.GameCode.GDBrassKeyObjects2.length = 0;
gdjs.GameCode.GDKeypadTriggerObjects1.length = 0;
gdjs.GameCode.GDKeypadTriggerObjects2.length = 0;
gdjs.GameCode.GDNewText2Objects1.length = 0;
gdjs.GameCode.GDNewText2Objects2.length = 0;

gdjs.GameCode.eventsList0(runtimeScene);
return;

}

gdjs['GameCode'] = gdjs.GameCode;
